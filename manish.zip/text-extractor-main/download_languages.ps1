# ─── Download All Missing Tesseract Language Files ───────────────────────────
$tessdata = "C:\Program Files\Tesseract-OCR\tessdata"
$baseUrl  = "https://github.com/tesseract-ocr/tessdata/raw/main"

$languages = @{
    "Spanish"            = "spa"
    "Italian"            = "ita"
    "Russian"            = "rus"
    "Portuguese"         = "por"
    "Chinese Simplified" = "chi_sim"
    "Japanese"           = "jpn"
    "Korean"             = "kor"
    "Arabic"             = "ara"
    "Bengali"            = "ben"
    "Turkish"            = "tur"
    "Dutch"              = "nld"
}

Write-Host "`n=== Tesseract Language Downloader ===" -ForegroundColor Cyan
Write-Host "Target folder: $tessdata`n" -ForegroundColor Gray

foreach ($name in $languages.Keys) {
    $code = $languages[$name]
    $file = "$tessdata\$code.traineddata"

    if (Test-Path $file) {
        Write-Host "  [SKIP] $name ($code) - already installed" -ForegroundColor Green
    } else {
        Write-Host "  [DOWNLOADING] $name ($code)..." -ForegroundColor Yellow
        try {
            Invoke-WebRequest -Uri "$baseUrl/$code.traineddata" -OutFile $file -UseBasicParsing
            Write-Host "  [OK] $name downloaded!" -ForegroundColor Green
        } catch {
            Write-Host "  [FAIL] $name - $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

Write-Host "`n=== Done! Restart your Streamlit app now. ===" -ForegroundColor Cyan
