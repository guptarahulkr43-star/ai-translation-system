@echo off
echo Starting AI Text Extraction ^& Translation App...
echo.
echo Open your browser at: http://localhost:8501
echo Press Ctrl+C to stop the app.
echo.
"C:\Users\Aman Maurya\AppData\Local\Programs\Python\Python312\python.exe" -m streamlit run "%~dp0app.py"
pause
